#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import os
import time

import numpy as np

my_dir = os.path.abspath(os.path.dirname(__file__))

#  ---------------------------------------------------------  #
#  functions                                                  #
#  ---------------------------------------------------------  #
def moving_average(x, n, type='simple'):
    """ compute an n period moving average.
        type is 'simple' | 'exponential'
    """
    x = np.asarray(x)
    if type=='simple':
        weights = np.ones(n)
    else:
        weights = np.exp(np.linspace(-1., 0., n))
    weights /= weights.sum()
    a =  np.convolve(x, weights, mode='full')[:len(x)]
    # a[:n] = a[n]
    ma = a[n:]
    # print ma
    # print len(ma)
    # sys.exit()
    return ma

# mpl_forcequench
# mpl_worm

#  ---------------------------------------------------------  #
#  Start matplotlib (1/4)                                     #
#  ---------------------------------------------------------  #
import matplotlib
# default - Qt5Agg
# print matplotlib.rcsetup.all_backends
# matplotlib.use('GTKAgg')
# matplotlib.use('TkAgg')
print 'backend:',matplotlib.get_backend()
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
fig = plt.figure(0)

gs = GridSpec(1,1)
ax1 = plt.subplot(gs[0,:])
# ax2 = plt.subplot(gs[1,:-1])
ax = [ax1]

#  ---------------------------------------------------------  #
#  Import Data! (2/4)                                         #
#  ---------------------------------------------------------  #
result_type = 'gsop' # sop | sopnucleo | gsop | namd
plot_type = 'proto_angles' # fe | tension | rmsd | rdf
data_name = 'test' # seed #
# save_fig(0,'fig','%s_%s_%s' % (result_type,plot_type,data_name))
combined_name = '%s_%s_%s' % (result_type, plot_type, data_name)

#  ---------------------------------------------------------  #
#  mpl_myargs_begin                                           #
#  ---------------------------------------------------------  #
import argparse

def parse_arguments():
    ''' Parse script's arguments.
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument("-o","--option",help="select None,publish,show")
    args = vars(parser.parse_args())
    return args

args = parse_arguments()
''' Options:
args['makefile']
args['procs']
args['node'])
'''
option = args['option']


#  ---------------------------------------------------------  #
#  Import Data! (3/4)                                         #
#  ---------------------------------------------------------  #
data = np.loadtxt('angle_test/contact_maps_new/tubulin_monomers_angles.dat')
print data.shape

ax1.set_color_cycle(['k','r','g','b','c','m','y','darkgoldenrod','firebrick',\
                     '#30a2da','#cbcbcb'])
for i in range(data.shape[1]):
    label = str(i+1) + '-' + str(i+2)
    x_raw = data[::,i]
    x = moving_average(x_raw,10)
    print x.shape
    y = np.linspace(0,data.shape[0],x.shape[0])
    print x.shape,y.shape
    plt.plot(x,y,label=label)
    ymin = min(y)
    ymax = max(y)
    # xmin = min(x)
    # xmax = max(x)
    ax1.set_ylim(ymax,ymin)
    # ax1.set_xlim(xmin,xmax)





#  ---------------------------------------------------------  #
#  Make final adjustments: (4/4)                              #
#  mpl - available expansions                                 #
#  ---------------------------------------------------------  #
# matplotlib.rcParams[''] =
# plt.subplots_adjust(left=0.180,right=0.960,top=0.950,bottom=0.160)
# font_prop_large = matplotlib.font_manager.FontProperties(size='large')
# fig.set_size_inches(9.0,5.1)
# for k in matplotlib.rcParams.keys():
#     print k
# dct_font = {'family':'sans-serif',
#             'weight':'normal',
#             'size'  :'28'}
# matplotlib.rc('font',**dct_font)
# matplotlib.rcParams['legend.frameon'] = False
# matplotlib.rcParams['figure.dpi'] = 900
# print matplotlib.rcParams['figure.dpi']

# # mpl_label
# for i in range(len(ax)):
#     # # tick label size
#     # ax[i] = plt.subplot(gs[0,i])
#     # ax[i].yaxis.set_major_locator(my_locator)
#     # ax[i].set_xlim()
#     ax[i].set_ylim(0.3,1.01)
#     if i == 0:
#         pass
#     else:
#         ax[i].set_yticklabels('',visible=False)
#     # for tick in ax.xaxis.get_major_ticks():
#     #     tick.label.set_fontsize(14)
#     #     # specify integer or one of preset strings, e.g.
#     #     #tick.label.set_fontsize('x-small')
#     #     tick.label.set_rotation('vertical')
#     # ax[i].yaxis(sharey=True)
#     # ax[i].tick_params()
#     # time.sleep(2)
#     ax[i].tick_params(axis='both',labelsize=8.0)
#     # yticklabels = ax[i].get_yticklabels()
#     # setp(yticklabels, fontsize=8.0)
#     # xticklabels = ax[i].get_xticklabels()
#     # setp(xticklabels, fontsize=8.0)

# plt.title('RMSD')
# Y
# plt.ylabel("Force (pN)")
# ax1.set_ylim(-12,342)

# # X
# if plot_type == 'extension':
#     plt.xlabel('Extension (nm)')
#     ax1.set_xlim(-2,82)
# elif plot_type == 'time':
#     plt.xlabel('t (ms)')
#     ax1.set_xlim(-0.5,38)
# elif plot_type == 'frame':
#     plt.xlabel('Frame # (x 1000)')
#     ax1.set_xlim(-0.5,9.5)
#     plt.xticks(np.linspace(0,9.0,19),fontsize=10)
#     # ax3.set_xticks(np.linspace(0,32.0,17))
#     # # Changing the label's font-size
#     # ax1.tick_params(axis='x',labelsize=8)
#     # ax2.tick_params(axis='x',labelsize=8)
#     # ax3.tick_params(axis='x',labelsize=8)

# mpl_xy: set_xlim,set_ylim,xticks,yticks
# ax1.set_xlim(-0.1,4.1)
# ax1.set_ylim(-0.1,6.1)
# plt.xticks([0.0,1.0,2.0,3.0,4.0])
# plt.yticks([0,1,2,3,4,5,6])

# mpl_ticks
# We change the fontsize of minor ticks label
# plt.tick_params(axis='both', which='major', labelsize=10)
# plt.tick_params(axis='both', which='minor', labelsize=8)
# plt.xticks(np.linspace(0.0,32.0,17),fontsize=10)
# ax1.set_xticks(np.linspace(0,32.0,17),fontsize=10)

# ax1.xaxis.set_major_locator(np.linspace(0.0,32.0,5.0))
# ax1.xaxis.set_minor_locator(np.linspace(0,32.0,17))

# majorFormatter = FormatStrFormatter('%d')
# minorLocator = matplotlib.ticker.MultipleLocator(2)
# majorLocator = matplotlib.ticker.MultipleLocator(4)
# ax1.xaxis.set_minor_locator(minorLocator)
# ax1.xaxis.set_major_locator(majorLocator)
# ax1.tick_params(which='both', width=1)
# ax1.tick_params(which='major', length=9)
# ax1.tick_params(which='minor', length=5, color='k')

# ax1.set_xticks(np.linspace(0.3,1.9,9))
# for tick in ax1.xaxis.get_major_ticks():
#     tick.label.set_fontsize(16)

# from matplotlib.ticker import AutoMinorLocator
# # One can supply an argument to AutoMinorLocator to
# # specify a fixed number of minor intervals per major interval, e.g.:
# # would lead to a single minor tick between major ticks.
# minorLocator   = AutoMinorLocator()
# # minorLocator = AutoMinorLocator(2)
# ax1.xaxis.set_minor_locator(minorLocator)
# plt.tick_params(which='both',width=2)
# plt.tick_params(which='major',length=9)
# plt.tick_params(which='minor',length=4,color='k')

# legend
# 1:
handles, labels = ax1.get_legend_handles_labels()
ax1.legend(handles, labels,prop={'size':10})
# 2:
# lst_labels = ['','',]
# ax1.legend(lst_labels,loc=2,prop={'size':18})
# 3:
# lst_labels = ['','',]
# leg = plt.gca().get_legend()
# for label in leg.get_lines():
#     label.set_linewidth(2.5)

# some lines in legend!
# print len(ax1.lines),ax1.lines
# lst_labels = ['0.3','0.4','0.5','0.6','0.7']
# for i,line in enumerate(ax1.lines[2:7]):
#     print lst_labels[i]
#     line.set_label(lst_labels[i])
# ax1.legend()

# save_fig
my_library = os.path.expanduser('~/.pylib')
sys.path.append(my_library)

# imports from my_library
# from mylib.cp import *
# from mylib.regex import *
# from mylib.run_command import *
# # from plot.WLC import WormLikeChain
# from plot.SOP import *
# from mdanalysis.MoleculeUniverse import MoleculeUniverse

from plot.SETTINGS import *
save_fig(my_dir,0,'fig','%s_%s_%s' % (result_type,plot_type,data_name),option)

#  ---------------------------------------------------------  #
#  mpl_myargs_end                                             #
#  ---------------------------------------------------------  #
# if option == None or 'None':
#     print 'saving (default) image .. dpi=%d' % matplotlib.rcParams['figure.dpi']
#     dir_fig = 'fig'
#     if not os.path.exists(dir_fig): os.makedirs(dir_fig)
#     plt.savefig('%s/%s_%s_%s.png' % (dir_fig,result_type,plot_type,data_name))
# elif option == 'show':
#     plt.show()
#     sys.exit()
# elif args['option'] == 'publish':
#     matplotlib.rcParams['figure.dpi'] = 1200
#     data_name = data_name + '_PUB'
#     print "calling save_fig ..."
#     # save_pic_data(levels_back,subdir,name)
#     # example: save_fig(-4,'fig',name)
#     # example: save_fig(-3,'',name)
#     # save_fig(0,'fig','%s_%s_%s' % (result_type,plot_type,data_name))
#     save_fig(0,'fig',combined_name)
