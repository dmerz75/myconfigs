#!/usr/bin/env python
import sys,os,pickle,shutil,fnmatch,itertools,time
import matplotlib.pyplot as plt
from pylab import *
from glob import glob
from sys import argv
import numpy as np

my_dir = os.path.abspath(os.path.dirname(__file__))
my_file= glob(os.path.join(my_dir,'out*.dat'))[0]

data = np.loadtxt(my_file)
print data.shape

#         plt.plot(d,data[0,::,3],'k',linewidth=0.4,label='Work(i)')
#         w_i = data[index,::,3]
#         plt.plot(d,w_i,'k',linewidth=0.3)
#         highest_work.append(w_i[-1])

# matplotlib begin
fig,(ax1)=plt.subplots(1)
plt.clf()
subplot(111)

plt.plot(data[::,0],data[::,int(sys.argv[1])],'k-',linewidth=0.5,label=sys.argv[2])

# # FONTSIZE    xx-small,x-small,small,medium,large,x-large,xx-large
fpropxxl=matplotlib.font_manager.FontProperties(size='xx-large')
fpropl=matplotlib.font_manager.FontProperties(size='large')

# # matplotlib end
plt.title('SOP',fontproperties=fpropxxl)
# # AXES labels
plt.xlabel('Steps',fontproperties=fpropl)
plt.ylabel(sys.argv[2],fontproperties=fpropl)
# plt.xlim([spos,spos+dist])
# # TICKS
# #list = [0,10,20,30]
# #plt.yticks(list,fontproperties=fpropxl)


# # LEGEND
# plt.legend(loc='lower right',prop={'size':14})
# leg = plt.gca().get_legend()
# leg.draw_frame(False)

# axis = plt.gca().yaxis.set_minor_locator(MultipleLocator(1))
# axis = plt.gca().xaxis.set_minor_locator(MultipleLocator(1))
# plt.subplots_adjust(left=0.11,right=0.99,top=0.97,bottom=0.13)
# fig.set_size_inches(7.12,4.4)

# DRAW
plt.draw()
# plt.show()

def save_pic_data(i,subdir,fname):
    content_dir = os.path.join('/'.join(my_dir.split('/')[0:i]),subdir)
    if not os.path.exists(content_dir): os.makedirs(content_dir)
    abs_file_name = os.path.join(content_dir,fname)
    plt.savefig('%s.png' % abs_file_name)
    plt.savefig('%s.eps' % abs_file_name)
    os.chdir(content_dir)
    #pickle.dump(pmf_2d,open('%s.pkl' % fname,'w'))
    #np.savetxt('%s.dat' % fname,pmf_2d,fmt=['%3.4f','%3.11f'],delimiter=' ')

# # levels back, -4:beyond,-3:default,-2:count,-1:env,'':cwd
# # save_pic_data(levels_back,subdir,name)
# # example: save_pic_data(-4,'fig',name)
# # example: save_pic_data(-3,'',name)
save_pic_data(None,'fig','sop%s' % sys.argv[2])
