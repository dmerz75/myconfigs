#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import os
import time
import numpy as np

my_dir = os.path.abspath(os.path.dirname(__file__))

#  ---------------------------------------------------------  #
#  functions                                                  #
#  ---------------------------------------------------------  #
# mylib
my_library = os.path.expanduser('~/.pylib')
sys.path.append(my_library)
from mylib.FindAllFiles import *
from mylib.moving_average import *
# mpl_moving_average
# mpl_forcequench
# mpl_worm

#  ---------------------------------------------------------  #
#  Start matplotlib (1/4)                                     #
#  ---------------------------------------------------------  #
import matplotlib
print 'backend:',matplotlib.get_backend()
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
fig = plt.figure(0)

gs = GridSpec(1,1)
ax1 = plt.subplot(gs[0,:])
# ax2 = plt.subplot(gs[1,:-1])
ax = [ax1]

#  ---------------------------------------------------------  #
#  Import Data! (2/4)                                         #
#  ---------------------------------------------------------  #
result_type = 'gsop' # sop | sopnucleo | gsop | namd
plot_type = 'proto_angles_3centroid' # fe | tension | rmsd | rdf
data_name = '3kin_2' # seed #
# save_fig(0,'fig','%s_%s_%s' % (result_type,plot_type,data_name))
combined_name = '%s_%s_%s' % (result_type, plot_type, data_name)

#  ---------------------------------------------------------  #
#  mpl_myargs_begin                                           #
#  ---------------------------------------------------------  #
import argparse

def parse_arguments():
    ''' Parse script's arguments.
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument("-n","--number",help="line_number, i.e. 196",type=int)
    parser.add_argument("-d","--data_name",help="so far: 4-1",type=int)
    parser.add_argument("-a","--angle",help="angle: n or e")
    parser.add_argument("-o","--option",help="select None,publish,show")
    parser.add_argument("-b","--barrier",help="barrier 15.0 deg",type=float)
    parser.add_argument("-t","--t",help="trajectory/trial number, 0,1,2,4,5 ..",type=int)
    args = vars(parser.parse_args())
    return args

args = parse_arguments()
''' Options:
args['makefile']
args['procs']
args['node'])
'''
line_size = args['number']
data_name = args['data_name']
angle = args['angle']
option = args['option']
barrier = args['barrier']
trajectory = args['t']

# ./plot_proto_angles_from3centroid.py -n 10 -d 123
# ./plot_proto_angles_from3centroid.py -d 123 -x 0  [1,2,3]

if line_size == None: # 10
    line_size = 10

#  ---------------------------------------------------------  #
#  Import Data! (3/4)                                         #
#  ---------------------------------------------------------  #
# FindAllFiles
def get_project_dct(type='mt_angles'):
    if type == 'mt_angles':
        dct_find = {'cwd':my_dir,'pattern':'mt_angles'}
        x = FindAllFiles(dct_find)
        x.get_files()
        # x.print_query(x.dct)
        # x.query_ [dirname,file,filename](dct,pos)
        # x.remove_[dirname,file,filename](dct,pos)
        # set9 = x.remove_dirname('B-partial')
        set9 = x.remove_filename('ew')
        # set9 = x.query_dirname('round9_r6',set9)
        # set9 = x.remove_dirname('dat',set9,-1)
        # print len(set9.keys()),'of',x.total
        set9 = x.sort_dirname(-2,set9)
        # x.print_query(set9)
    elif type == 'inter':
        dct_find = {'cwd':my_dir,'pattern':'tubulin_inter_monomer'}
        x = FindAllFiles(dct_find)
        x.get_files()
        set9 = x.dct
        # set9 = x.sort_dirname(-2,set9)
    return x,set9
# if re.search('i',dataname) != None:
#     x,set9 = get_project_dct('inter')
# else:
#     x,set9 = get_project_dct('mt_angles')
print data_name,' from ','123','134','145','156','i','odd','even' # i=inter,vertex; odd-noi, even-i
# sys.exit()

# x.print_query(set9)
# if dataname == '123':

# FindAllFiles
dct_find = {'cwd':my_dir,'pattern':'dat'}
x = FindAllFiles(dct_find)
x.get_files()
# x.print_query(x.dct)
set9 = x.dct
print len(x.dct.keys()),'of',x.total
# sys.exit()
# x.dct (last pos.)
# x.sort_dirname
# x.print_query,_class
# x.query_ [dirname,file,filename](searchstring,pos,dct)
# x.remove_[dirname,file,filename](searchstring,pos,dct)
set9 = x.query_dirname('3kinesin',-3)
set9 = x.query_filename('tubulin',set9)
set9 = x.remove_dirname('fail',-2,set9)
set9 = x.remove_dirname('contact_maps',-1,set9)
set9 = x.sort_dirname(-2,set9)
# x.print_query(set9)
print len(set9.keys()),'of',x.total
# sys.exit()


# if '123' in dataname:
#     set9 = x.query_dirname('kinesin13_123',set9,-2)
#     set9 = x.sort_dirname(-1,set9)
# # elif dataname == '134':
# elif '134' in dataname:
#     set9 = x.query_dirname('kinesin13_134',set9,-2)

# # elif dataname == '145':
# elif '145' in dataname:
#     set9 = x.query_dirname('kinesin13_145',set9,-2)
#     set9 = x.sort_dirname(-1,set9)
# # elif dataname == '156':
# elif '156' in dataname:
#     set9 = x.query_dirname('kinesin13_156',set9,-2)
#     set9 = x.sort_dirname(-1,set9)

# data_name
set9 = x.query_dirname(str(data_name),-2,set9)
set9 = x.sort_dirname(-1,set9)
x.print_query(set9)
print len(set9.keys()),'of',x.total

# trajectory
set9 = x.query_dirname(str(trajectory),-1,set9)
set9 = x.sort_dirname(-1,set9)
x.print_query(set9)
print len(set9.keys()),'of',x.total
# sys.exit()



# if trajectory == None:
#     data_name = dataname
# else:
#     data_name = dataname + '_x' + str(trajectory)
# sys.exit()


def load_data(filename,line_size):
    x = np.loadtxt(filename)
    nr,nc = x.shape
    data = x.reshape(nr/line_size,line_size,4)
    print data.shape
    return data


# color cycle
from cycler import cycler
colors = ['k','r','g','b','c','m',\
          'darkgoldenrod','darksalmon',\
          'darkmagenta','chartreuse','darkturquoise']
marker = ['.','^','s','o','p']
ax1.set_prop_cycle(cycler('color',colors))

# if 'i' not in str(data_name):
#     ax1.set_prop_cycle(cycler('color',['k','r','g','b','c','m',\
#                                        'darkgoldenrod','darksalmon',\
#                                        'darkmagenta','chartreuse']))
# else:
#     ax1.set_prop_cycle(cycler('color',['k','r','g','b','c','m',\
#                                        'darkgoldenrod','darksalmon',\
#                                        'darkmagenta','chartreuse','darkturquoise']))
# if 'odd' in str(data_name):
#     ax1.set_prop_cycle(cycler('color',['k','r','g','b','c','m',\
#                                        'darkgoldenrod','darksalmon',\
#                                        'darkmagenta','chartreuse']))
# else:
#     ax1.set_prop_cycle(cycler('color',['k','r','g','b','c','m',\
#                                        'darkgoldenrod','darksalmon',\
#                                        'darkmagenta','chartreuse','darkturquoise']))

# linestyle = ['-','--','^','o',]


print len(set9.keys())
for i,n in enumerate(1,range(len(set9.keys()))):
    print 'i',i


    if trajectory != None:
        if i != trajectory:
            continue

    try:
        ms = marker[i]
    except:
        # print __line__
        # raise SystemExit
        print 'run out of markers'
        sys.exit(1)
        # break


    if 'i' not in dataname:
        data = load_data(set9[n]['file'],line_size)
    else:
        data = np.loadtxt(set9[n]['file'])


    if 'i' not in dataname:
        for a in range(0,line_size):
            print a
            color = colors[a]
            if re.search('odd',dataname) != None:
                if a % 2 == 0:
                    continue
            if re.search('even',dataname) != None:
                if a % 2 != 0:
                    continue


            lc = int(data[0,a,0])
            lw = int(data[0,a,1])
            le = int(data[0,a,2])
            # print lc,lw,le
            label = str(lw) + '-' + str(lc) + '-' + str(le)

            d1 = moving_average(data[::,a,3],25)
            print d1.shape


            mcount = int(d1.shape[0] / 80)
            # x = np.linspace(1,d1.shape[0],data.shape[0])
            x = np.linspace(1,d1.shape[0],d1.shape[0])


            # plt.plot(x,d1,label=label,linestyle=ls,marker=ms)
            # plt.plot(x,d1,label=label,marker=ms,markevery=mcount,linestyle='None',markersize=5)
            plt.plot(x,d1,label=label,color=color,
                     marker=ms,markevery=mcount,linewidth=1,markersize=5)  #***
    else:
        for a in range(data.shape[1]):
            print a
            color = colors[a]
            if re.search('odd',dataname) != None:
                if a % 2 == 0:
                    continue
            if re.search('even',dataname) != None:
                if a % 2 != 0:
                    continue

            lw = int(a+1)
            le = int(a+2)
            label = str(lw) + '-' + str(le)

            d1 = moving_average(data[::,a],25)
            print d1.shape


            mcount = int(d1.shape[0] / 80)
            x = np.linspace(1,d1.shape[0],d1.shape[0])
            # plt.plot(x,d1,label=label,marker=ms,markevery=mcount,linestyle='None',markersize=5)
            plt.plot(x,d1,label=label,color=color,
                     marker=ms,markevery=mcount,linewidth=1,markersize=5) #***


#  ---------------------------------------------------------  #
#  Make final adjustments: (4/4)                              #
#  mpl - available expansions                                 #
#  ---------------------------------------------------------  #
# mpl_rc
# mpl_font
# mpl_label
# mpl_xy

plt.ylabel("Angle (deg.)")
plt.xlabel("Frame (x5)")

# plt.yticks([20,40,60])


# plt.yticks([15,30,45])
# plt.xticks([250,500,750,1000])
plt.yticks([0,30,60,90,120,150])
plt.xticks([0,750,1500,2250,3000])
plt.ylim([-2,170])
plt.xlim([-30,3200])


# mpl_ticks
# mpl_tick
# mpl_minorticks
# legend
# 1:
handles, labels = ax1.get_legend_handles_labels()

# handles = handles[0:10]
# labels = labels[0:10]

if 'i' not in str(data_name):
    handles = handles[-10:]
    labels = labels[-10:]
else:
    handles = handles[-11:]
    labels = labels[-11:]

if 'odd' in str(data_name):
    handles = handles[-5:]
    labels = labels[-5:]
else:
    handles = handles[-6:]
    labels = labels[-6:]


ax1.legend(handles, labels,prop={'size':12},loc=2)
# 2:
# lst_labels = ['','',]
# ax1.legend(lst_labels,loc=2,prop={'size':18})
# 3:
# lst_labels = ['','',]
leg = plt.gca().get_legend()
for label in leg.get_lines():
    label.set_linewidth(2.5)

# some lines in legend!
# print len(ax1.lines),ax1.lines
# lst_labels = ['0.3','0.4','0.5','0.6','0.7']
# for i,line in enumerate(ax1.lines[2:7]):
#     print lst_labels[i]
#     line.set_label(lst_labels[i])
# ax1.legend()

data_name = str(data_name) + '_' + str(trajectory)
# data_name = str(data_name) + '_' + str(trajectory) + '_' + unit
# save_fig
from plot.SETTINGS import *
save_fig(my_dir,0,'fig','%s_%s_%s' % (result_type,plot_type,data_name),option)
# mpl_myargs_end
